package Tela;

import Model.Caminhao;
import Model.Carro;
import Model.Veiculo;

public class TelaPrincipal {
    public static  void main (String args[]){

        Caminhao cm = new Caminhao();
        cm.setMarca("BBM");
        cm.setModelo("Bitrem");
        cm.setNroDeEixos(8);
        cm.ligar();

        Carro cr = new Carro();
        cr.setMarca("BMW");
        cr.setModelo("Sedan");
        cr.setTamanhoPortaMalas(1500);
        cr.ligar();
        cr.desligar();


    }
}
