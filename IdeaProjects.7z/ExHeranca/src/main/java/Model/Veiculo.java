package Model;

public class Veiculo {
    private String marca;
    private String modelo;

    public void ligar(){
        System.out.println("Veiculo ligado");
    }

    public void desligar(){
        System.out.println("Veiculo desligado");
    }
    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
}
