package Model;

public class Carro  extends Veiculo{
    private float tamanhoPortaMalas;

    public float getTamanhoPortaMalas() {
        return tamanhoPortaMalas;
    }
    @Override
    public void ligar() {
        System.out.println("Carro ligado");;
    }

    @Override
    public void desligar() {
        System.out.println("Carro desligado");
    }

    public void setTamanhoPortaMalas(float tamanhoPortaMalas) {
        this.tamanhoPortaMalas = tamanhoPortaMalas;
    }
}
