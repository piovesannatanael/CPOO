package Model;

public class Caminhao extends Veiculo{
    private int nroDeEixos;

    public int getNroDeEixos() {
        return nroDeEixos;
    }

    @Override
    public void ligar() {
        System.out.println("Caminhão ligado");;
    }

    @Override
    public void desligar() {
        System.out.println("Caminhão desligado");
    }

    public void setNroDeEixos(int nroDeEixos) {
        this.nroDeEixos = nroDeEixos;
    }

    @Override
    public String toString() {
       return ;
    }
}
