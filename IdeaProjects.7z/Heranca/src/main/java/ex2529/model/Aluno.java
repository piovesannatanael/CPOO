package ex2529.model;

public class Aluno extends Pessoa{

    private String matricula;

    public Aluno(){
        System.out.println("Criando Aluno");
    }

    public String getMatricula() {
        return matricula;
    }

    @Override
    public String toString() {
        return "Aluno: "+super.toString() +" - "+ this.matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }
}
