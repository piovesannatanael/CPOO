package ex2529.model;

public class Professor extends Pessoa{
    private String siape;

    public Professor(){
        System.out.println("Criando Professor");
    }
    public String getSiape() {
        return siape;
    }

    @Override
    public String toString() {
        return "Professor"+super.toString() + " - "+ this.siape ;
    }

    public void setSiape(String siape) {
        this.siape = siape;
    }
}
