package ex2529.tela;

import ex2529.model.Aluno;
import ex2529.model.Professor;

public class Tela {
    public static void main (String [] args){
        Aluno a = new Aluno();
        a.setId(616);
        a.setNome("Nata");
        a.setCpf("984.943.314-46");
        a.setEndereco("Av. Roraima");
        a.setMatricula("2020216565");

        System.out.println(a.toString());
        Professor p = new Professor();
        p.setId(645);
        p.setNome("Jose");
        p.setCpf("135.654.164-79");
        p.setEndereco("Av. Roraima");
        p.setSiape("13587");
        System.out.println(p);

    }
}
