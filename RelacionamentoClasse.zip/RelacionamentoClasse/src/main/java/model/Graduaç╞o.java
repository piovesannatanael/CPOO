package model;

public class Graduação {

    private String sigla;
    private String nome;
    private String turno;
    private int ingAno;

    public String getSigla() {
        return sigla;
    }

    public void setSigla(String sigla) {
        this.sigla = sigla;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTurno() {
        return turno;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }

    public int getIngAno() {
        return ingAno;
    }

    public void setIngAno(int ingAno) {
        this.ingAno = ingAno;
    }
}
