package telas;

import model.Aluno;
import model.Disciplina;
import model.Graduação;
import model.Professor;

import java.util.ArrayList;

public class TelaPrincipal {

    public static void main (String []args){
        Professor p = new Professor();
        p.setNome("Alencar");
        p.setArea("Computação");
        p.setEndereco("Roraima");
        p.setMatricula(2624152);
        p.setTitulacao("Dr");

        Aluno a = new Aluno();
        a.setNome("Natanael");
        a.setEndereco("Roraima");
        a.setMatricula(2020620511);
        a.setAnoIng(2023);
        a.setSemIng(2);

        Aluno b = new Aluno();
        b.setNome("Gabriel");
        b.setEndereco("Roraima");
        b.setMatricula(2020625454);
        b.setAnoIng(2022);
        b.setSemIng(1);

        Graduação g = new Graduação();
        g.setSigla("ECOMP");
        g.setNome("Engenharia da Computação");
        g.setTurno("Diurno");
        g.setIngAno(30);

        Disciplina d = new Disciplina();
        d.setCodigo("CPOO");
        d.setNome("Programação Orientada a Objetos");
        d.setPreReq("Algoritmos");
        d.setProfessor(p);
        d.setGraduação(g);


        ArrayList<Aluno> alunos = new ArrayList();
        alunos.add(a);
        alunos.add(b);

        d.setAlunos(alunos);

        imprimirDisciplina(d);


        Disciplina d2 = new Disciplina();
        d2.setCodigo("BD");
        d2.setNome("Banco de Dados");
        d2.setPreReq("Algoritmos");
        d2.setProfessor(p);
        d2.setGraduação(g);
        d2.setAlunos(alunos);

        imprimirDisciplina(d2);
    }


    private static void imprimirDisciplina(Disciplina d){
        System.out.println("IMPRIMIR DISCIPLINA");
        System.out.println("Curso: "+d.getGraduação().getNome());
        System.out.println("Nome: "+d.getNome());
        System.out.println("Codigo: "+d.getCodigo());
        System.out.println("Pré-Requisito: "+d.getPreReq());
        System.out.println("Professor: "+d.getProfessor().getNome());
        System.out.println("Alunos matriculados: ");
        for (Aluno a : d.getAlunos()){
            System.out.println("Nome: "+a.getNome());
        }


    }
}
